import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, TextInput } from 'react-native';
import React, { useState } from 'react';


export default function App() {
  const [username, setName] = useState('');
  const [birthday, setBirth] = useState('');
  const [address, setAdd] = useState('');
  const [email, setEmail] = useState('');

  return (
    <View style={styles.container}>

      <Text>User information</Text>
      <TextInput
        style={styles.input}
        placeholder='username'
        onChangeText={(username) => setName(username)}
        value={username}
      />
      <TextInput
        style={styles.input}
        placeholder='birthday'
        onChangeText={(birthday) => setBirth(birthday)}
        value={birthday}
      />
      <TextInput
        style={styles.input}
        placeholder='address'
        onChangeText={(address) => setAdd(address)}
        value={address}
      />
      <TextInput
        style={styles.input}
        placeholder='email'
        onChangeText={(email) => setEmail(email)}
        value={email}
      />
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});


