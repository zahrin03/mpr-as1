import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Alert, Pressable } from 'react-native';



export default function App() {

  const handlePress = () => {
    Alert.alert('tuyet voi');
  };

  return (

    <View style={styles.container}>
      <StatusBar style="auto" />

      <Text style={{ padding: 10, color: 'black', fontSize: 27 }}>Best
        <Text style={{ padding: 10, color: '#f4a2bb', fontSize: 28, fontWeight: 'bold' }}> Shared Hosting</Text> Company</Text>

      <Text style={{ padding: 10, color: 'black' }} >This exercise emphasizes the importance of responsive design
        in React Native and provides you with hands-on experience in
        adapting web-based layouts for mobile applications.</Text>

      <View style={styles.twoBox}>

        <View>
          <Pressable onPress={handlePress} style={styles.pressMe}>
            <Text style={{ padding: 10, color: 'white' }} >Press Me</Text>
          </Pressable>
        </View>

        <View>
          <Pressable onPress={handlePress} style={styles.viewDetail}>
            <Text style={{ padding: 10, color: 'white' }}>View details</Text>
          </Pressable>
        </View>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  twoBox: {
    flexDirection: 'row',
    backgroundColor: '#f4a2bb',
    alignItems: 'center',
    justifyContent: 'center',
    width: 390,
    height: 20,
    marginTop: 140
  },
  pressMe: {
    backgroundColor: '#424242',
    alignItems: 'center',
    justifyContent: 'center',
    width: 120,
    height: 50,
    borderWidth: 0.5,
    borderRadius: 10,
    margin: 10
  },
  viewDetail: {
    backgroundColor: '#424242',
    alignItems: 'center',
    justifyContent: 'center',
    width: 120,
    height: 50,
    borderWidth: 0.5,
    borderRadius: 10,
    margin: 10
  }
});




