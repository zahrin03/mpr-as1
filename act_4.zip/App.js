import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Alert, Pressable, Image } from 'react-native';



export default function App() {

  const handlePress = () => {
    Alert.alert('tuyet voi');
  };
  return (
    <View style={styles.container}>

      <StatusBar style="auto" />

      <View style={{ flexDirection: 'row', padding: 1 }}>
        <Image
          source={require('D:/Programming/reactNative/HelloNativeProject/halongbay.jpg')}
          style={{ width: 140, height: 220, marginRight: 10 }}
        />

        <View style={{ flex: 1 }}>
          <Text style={{ padding: 1, color: 'black', fontSize: 22, marginLeft: 10, }}>HA LONG BAY</Text>
          <Text style={{ padding: 1, color: 'black', marginLeft: 10 }} >In this exercise, you will work on adapting a web design. </Text>
          <Text style={{ padding: 1, color: 'black', marginLeft: 10 }} >This exercise emphasizes the importance of onsive design.</Text>
          <Text style={{ padding: 1, color: 'black', marginLeft: 10 }} >This exercise emphasizes the importance of onsive design.</Text>

          <Pressable onPress={handlePress} style={styles.viewDetail}>
            <Text style={{ padding: 1, color: 'black' }}>View details</Text>
          </Pressable>

        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  viewDetail: {
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    width: 90,
    height: 30,
    borderWidth: 0.5,
    marginBottom: 20,
    marginLeft: 10
  }
});




